<?php
global $wpdb;
 $selectsql = "SELECT * FROM ".$wpdb->prefix . "code_generator";
        $codearray = $wpdb->get_results($selectsql) ;

       print_r($codearray);
?>
<div class="wrap"><h2>Code Generator Manager</h2>
<table class="widefat">
<thead>
    <tr>
        <th>#</th>
        <th>code</th>       
        <th>Max</th>
        <th>Used</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
</thead>
<tfoot>
    <tr>
        <th>#</th>
        <th>code</th>       
        <th>Max</th>
        <th>Used</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
</tfoot>
<tbody>
   <?php if(!empty($codearray)){
       
       $as =1; $codeStatus ='';
       foreach($codearray as $row){
           $addClass='';
           if($row->status == '1'){ $codeStatus ='Active';}elseif ($row->status == '2') {$codeStatus ='Deactivate';}
                
            
            if($as % 2 != 0){ $addClass = 'class="alternate"';}
                
       ?>
    <tr valign="top" <?php echo $addClass; ?> > 
            <th class="check-column" scope="row"><?php echo $as; ?></th>
            <td class="column-columnname"> <?php echo $row->codetext; ?> </td>
            <td class="column-columnname">  <?php echo $row->uselimit; ?> </td>
            <td class="column-columnname"> <?php echo $row->codeused; ?> </td>
            <td class="column-columnname"> <?php echo $codeStatus;  ?></td>
            <td class="column-column"><span><a href="#">Action</a></span></td>
        </tr>
            <?php 
            $as++;
         }
       } ?> 
</tbody>
</table>