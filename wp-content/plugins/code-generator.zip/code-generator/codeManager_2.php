<?php


if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class MY_Plugin_List_Table extends WP_List_Table {
    
    
    function __construct(){
        global $status, $page;
                
        //Set parent defaults
        parent::__construct( array(
            'singular'  => 'mycode',     //singular name of the listed records
            'plural'    => 'mycodes',    //plural name of the listed records
            'ajax'      => false        //does this table support ajax?
        ) );
        
    }
    
    
    function column_default($item, $column_name){
        switch($column_name){
            case 'rating':
            case 'director':
                return $item[$column_name];
            default:
                return print_r($item,true); //Show the whole array for troubleshooting purposes
        }
    }
    
        
    
    function column_title($item){
        
        //Build row actions
        $actions = array(
            'edit'      => sprintf('<a href="?page=%s&action=%s&movie=%s">Edit</a>',$_REQUEST['page'],'edit',$item['ID']),
            'delete'    => sprintf('<a href="?page=%s&action=%s&movie=%s">Delete</a>',$_REQUEST['page'],'delete',$item['ID']),
        );
        
        //Return the title contents
        return sprintf('%1$s <span style="color:silver">(id:%2$s)</span>%3$s',
            /*$1%s*/ $item['code'],
            /*$2%s*/ $item['id'],
            /*$3%s*/ $this->row_actions($actions)
        );
    }
    
  
    function column_cb($item){
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            /*$1%s*/ $this->_args['singular'],  //Let's simply repurpose the table's singular label ("movie")
            /*$2%s*/ $item['id']                //The value of the checkbox should be the record's id
        );
    }
    
    
   
    function get_columns(){
        $columns = array(
            'cb'        => '<input type="checkbox" />', //Render a checkbox instead of text
            'code'      => 'Code',
            'max'       => 'Max',
            'used'      => 'Used',
            'status'    => 'Status',
            'action'    => 'Action'
        );
        return $columns;
    }
    
   
    function get_sortable_columns() {
        $sortable_columns = array(
            'code'      => array('title',false),     //true means it's already sorted
            'max'       => array('max',false),
            'used'      => array('used',false),
            'status'    => array('status',false)
           
        );
        return $sortable_columns;
    }
    
    
  
    function get_bulk_actions() {
        $actions = array(
            'delete'    => 'Delete'
        );
        return $actions;
    }
    
    
    /** ************************************************************************
     * Optional. You can handle your bulk actions anywhere or anyhow you prefer.
     * For this example package, we will handle it in the class to keep things
     * clean and organized.
     * 
     * @see $this->prepare_items()
     **************************************************************************/
    function process_bulk_action() {
        
        //Detect when a bulk action is being triggered...
        if( 'delete'===$this->current_action() ) {
            wp_die('Items deleted (or they would be if we had items to delete)!');
        }
        
    }
    
    
    /** ************************************************************************
     * REQUIRED! This is where you prepare your data for display. This method will
     * usually be used to query the database, sort and filter the data, and generally
     * get it ready to be displayed. At a minimum, we should set $this->items and
     * $this->set_pagination_args(), although the following properties and methods
     * are frequently interacted with here...
     * 
     * @global WPDB $wpdb
     * @uses $this->_column_headers
     * @uses $this->items
     * @uses $this->get_columns()
     * @uses $this->get_sortable_columns()
     * @uses $this->get_pagenum()
     * @uses $this->set_pagination_args()
     **************************************************************************/
    
  
        
    
    
             function prepare_items() {
	global $wpdb, $_wp_column_headers;
	$screen = get_current_screen();

	/* -- Preparing your query -- */
        $query = "SELECT * FROM ".$wpdb->prefix . "code_generator";

	/* -- Ordering parameters -- */
	    //Parameters that are going to be used to order the result
	    $orderby = !empty($_GET["orderby"]) ? mysql_real_escape_string($_GET["orderby"]) : 'ASC';
	    $order = !empty($_GET["order"]) ? mysql_real_escape_string($_GET["order"]) : '';
	    if(!empty($orderby) & !empty($order)){ $query.=' ORDER BY '.$orderby.' '.$order; }

	/* -- Pagination parameters -- */
        //Number of elements in your table?
        $totalitems = $wpdb->query($query); //return the total number of affected rows
        //How many to display per page?
        $perpage = 5;
        //Which page is this?
        $paged = !empty($_GET["paged"]) ? mysql_real_escape_string($_GET["paged"]) : '';
        //Page Number
        if(empty($paged) || !is_numeric($paged) || $paged<=0 ){ $paged=1; }
        //How many pages do we have in total?
        $totalpages = ceil($totalitems/$perpage);
        //adjust the query to take pagination into account
	    if(!empty($paged) && !empty($perpage)){
		    $offset=($paged-1)*$perpage;
    		$query.=' LIMIT '.(int)$offset.','.(int)$perpage;
	    }

	/* -- Register the pagination -- */
		$this->set_pagination_args( array(
			"total_items" => $totalitems,
			"total_pages" => $totalpages,
			"per_page" => $perpage,
		) );
		//The pagination links are automatically built according to those parameters

	/* -- Register the Columns -- */
//		$columns = $this->get_columns();
//		$_wp_column_headers[$screen->id]=$columns;
                
                    $columns = $this->get_columns();
                    $hidden = array();
                    $sortable = $this->get_sortable_columns();
                    $this->_column_headers = array($columns, $hidden, $sortable);

	/* -- Fetch the items -- */
		$this->items = $wpdb->get_results($query);
        }
        
        function display_rows() {

	//Get the records registered in the prepare_items method
	$records = $this->items;

	//Get the columns registered in the get_columns and get_sortable_columns methods
	list( $columns, $hidden ) = $this->get_column_info();
            $rowlist= '';
       // pr($columns);
        
	//Loop for each record
     
	if(!empty($records)){foreach($records as $rec){

                    //Open the line
       $rowlist.= '< tr id="record_'.$rec->id.'">';
		foreach ( $columns as $column_name => $column_display_name ) {

			//Style attributes for each col
			$class = "class='$column_name column-$column_name'";
			$style = "";
			if ( in_array( $column_name, $hidden ) ) $style = ' style="display:none;"';
			$attributes = $class . $style;

			//edit link
			//$editlink  = '/wp-admin/link.php?action=edit&link_id='.(int)$rec->link_id;

			//Display the cell
			switch ( $column_name ) {
				case "cb":	$rowlist.= '< td '.$attributes.'>'.$column_display_name.'< /td>';	break;
				case "code": $rowlist.= '< td '.$attributes.'>'.($rec->codetext).'< /td>'; break;
                                case "max": $rowlist.= '< td '.$attributes.'>'.($rec->uselimit).'< /td>'; break;
				case "used": $rowlist.= '< td '.$attributes.'>'.$rec->codeused.'< /td>'; break;
				case "status": $rowlist.= '< td '.$attributes.'>'.$rec->status.'< /td>'; break;
                                case "action": $rowlist.= '< td '.$attributes.'>DELETE< /td>'; break;
			}
		}

		//Close the line
               return	$rowlist.='< /tr>';
	
       
                }
         }
}
}



function my_render_list_page(){
          
         
    $myListTable = new MY_Plugin_List_Table();

    $myListTable->prepare_items();
    ?>    
  <div class="wrap"><h2>Code Generator Manager</h2>
      <form id="mycode-filter" method="get">
           
            <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
                     <?php $myListTable->display() ?>
            </form>
  </div> 
<?php }
my_render_list_page();
?>
